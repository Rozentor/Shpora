﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Shpora.WordSearcher
{
    public class WordSearcher
    {
        private IRoadBuilder roadBuilder;
        private IMover mover;
        private IFieldManager fieldManager;
        private IWordReader wordReader;
        private IWordCollector wordCollector;

        public WordSearcher(GameClient client, Size viewableSize)
        {
            mover = new Mover();
            mover.OnStep += (dir) => mover.CurPosition.SetCoordinatesInField(fieldManager.FieldSize);
            fieldManager = new FieldManager(client, viewableSize);
            fieldManager.SubscribeOn(mover);
            wordReader = new WordReader(new ShporaLetterConverter(), mover, fieldManager, viewableSize);
            wordCollector = new WordCollector();
        }

        public IEnumerable<string> GetWords()
        {
            FindFirstWordWithSpiralRB();
            FindMapWidthWithLinearRB();
            ReadAllWordsWithSnakeRB();
            return wordCollector.GetAllWords()
                                .OrderBy(word => word.Length);
        }

        private void FindFirstWordWithSpiralRB()
        {
            roadBuilder = new SpiralRoadBuilder(fieldManager.ViewableSize, mover);
            Walk(() => wordCollector.WordsCount > 0,
                  fieldManager.IsFieldNotEmpty,
                  null);
        }

        private void FindMapWidthWithLinearRB()
        {
            roadBuilder = new LinearRoadBuilder(fieldManager.ViewableSize, mover);
            Walk(() => fieldManager.FieldSize.Width > 0,
                () => wordReader.IsLetter(fieldManager.GetFieldAsString()),
                (duplicate) =>
                {
                    fieldManager.FieldSize.Width = Math.Abs(duplicate.LeftTop.X - wordCollector.FirstWordCase.LeftTop.X);
                    wordCollector.FirstWordCase.LeftTop.SetCoordinatesInField(fieldManager.FieldSize);
                    wordCollector.FirstWordCase.RightBottom.SetCoordinatesInField(fieldManager.FieldSize);
                });
        }

        private void ReadAllWordsWithSnakeRB()
        {
            roadBuilder = new SnakeRoadBuilder(fieldManager.ViewableSize, mover, fieldManager.FieldSize);
            Walk(() => fieldManager.FieldSize.Height > 0,
                  () => IsFieldContainsAnyNewPoints() && roadBuilder.CurDirection != Direction.Down,
                  (duplicate) => fieldManager.FieldSize.Height = Math.Abs(duplicate.LeftTop.Y - wordCollector.FirstWordCase.LeftTop.Y)
            );
        }

        private void Walk(
            Func<bool> endCondition,
            Func<bool> conditionToStartReading,
            Action<WordCase> duplicateFound)
        {
            while (true)
            {
                mover.StepTo(roadBuilder.Destination);
                if (!conditionToStartReading()) continue;
                var edgeOfLetter = fieldManager.GetPoints(mover.CurPosition)
                                               .Find(p => !wordCollector.ContainsInWordCases(p));
                if (edgeOfLetter == null)
                    continue;
                roadBuilder.SaveDestination();
                var wordCase = wordReader.GetWord(roadBuilder.CurDirection, edgeOfLetter, fieldManager.FieldSize);
                if (!wordCollector.Contains(wordCase))
                {
                    wordCollector.Add(wordCase);
                    wordCollector.FilterWordsByYCoordinate(mover.CurPosition.Y, 15);
                }
                else
                    duplicateFound(wordCase);
                if (endCondition())
                    break;
                while (!roadBuilder.ReturnedToOldDestination())
                    mover.StepTo(roadBuilder.Destination);
            }
        }

        private bool IsFieldContainsAnyNewPoints()
        {
            var foundedPoints =
                fieldManager.GetPointsInSubField(mover.CurPosition, 0, fieldManager.ViewableSize.Height / 2, 0, fieldManager.ViewableSize.Width - 1);
            return foundedPoints.Any(p => !wordCollector.ContainsInWordCases(p));
        }
    }
}