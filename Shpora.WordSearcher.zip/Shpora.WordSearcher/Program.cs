﻿using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Shpora.WordSearcher
{
    static class Program
    {
        public static void Main(string[] args)
        {
            var uri = args[0];
            var key = args[1];
            using (var client = new GameClient(uri, key))
            {
                var info = client.InitSession();
                if (info.Status == Status.Conflict)
                    client.InitSession();
                var ws = new WordSearcher(client, new Size(7, 7));
                var words = ws.GetWords();
                client.SendWords(words);
                var stat = client.GetStatistics();
                client.FinishSession();
            }
        }
    }
}