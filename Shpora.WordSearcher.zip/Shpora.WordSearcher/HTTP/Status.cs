﻿namespace Shpora.WordSearcher
{
    public enum Status
    {
        Success,
        Unauthorized,
        Forbidden,
        Conflict,
        TooManyRequests
    }
}