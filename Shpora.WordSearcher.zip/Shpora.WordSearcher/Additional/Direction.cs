﻿namespace Shpora.WordSearcher
{
    public enum Direction
    {
        Up,
        Left,
        Right,
        Down
    }
}