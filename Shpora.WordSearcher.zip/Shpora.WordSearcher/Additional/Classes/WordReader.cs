﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Shpora.WordSearcher
{

    public class WordReader : IWordReader
    {
        private readonly IMover mover;
        private readonly IFieldManager fieldManager;
        private readonly ILetterConverter converter;
        private readonly Size viewableSize;
        public WordReader(ILetterConverter converter, IMover mover, IFieldManager fieldManager, Size viewableSize)
        {
            this.mover = mover;
            this.fieldManager = fieldManager;
            this.converter = converter;
            this.viewableSize = viewableSize;
        }

        public bool IsLetter(string fieldAsString)
        {
            return converter.IsLetter(fieldAsString);
        }

        public WordCase GetWord(Direction currentMovingDirection, Point edgeOfLetter, Size fieldSize)
        {
            var directionOfReading = GetDirectionOfReading(currentMovingDirection);
            ReachEdgeOfLetter(edgeOfLetter, fieldSize);
            ReachLevelOfLetter();
            ReachBorderOfWord(directionOfReading);

            var wordCase = new WordCase();

            if (directionOfReading == Direction.Right)
                wordCase.SetLeftTop(mover.CurPosition, viewableSize, fieldSize);
            else
                wordCase.SetRightBottom(mover.CurPosition, viewableSize, fieldSize);

            var word = ReadWord(directionOfReading, viewableSize.Width + 1);
            if (directionOfReading == Direction.Right)
            {
                var centerOfLastLetter = new Point(mover.CurPosition.Y, mover.CurPosition.X - viewableSize.Width - 1);
                wordCase.SetRightBottom(centerOfLastLetter, viewableSize, fieldSize);
            }
            else
            {
                var centerOfLastLetter =
                    new Point(mover.CurPosition.Y, mover.CurPosition.X + viewableSize.Width + 1);
                wordCase.SetLeftTop(centerOfLastLetter, viewableSize, fieldSize);
            }

            if (directionOfReading == Direction.Left)
                word = new string(word.Reverse().ToArray());

            wordCase.Word = word;
            return wordCase;
        }

        private Direction GetDirectionOfReading(Direction currentMovingDirection)
        {
            return currentMovingDirection == Direction.Left ? currentMovingDirection : Direction.Right;
        }

        private string ReadWord(Direction directionOfReading, int distanceBetweenLetters)
        {
            var res = "";
            while (converter.IsLetter(fieldManager.GetFieldAsString()))
            {
                res += converter.ConvertToLetter(fieldManager.GetFieldAsString());
                mover.Move(directionOfReading, distanceBetweenLetters);
            }
            return res;
        }

        private void ReachEdgeOfLetter(Point edge, Size fieldSize)
        {
            var dx = Math.Abs(mover.CurPosition.X - edge.X);
            if (dx <= 3)
            {
                if (mover.CurPosition.X > edge.X)
                    mover.Move(Direction.Left, dx);
                else
                    mover.Move(Direction.Right, dx);
            }
            else
            {
                dx = Math.Abs(dx - fieldSize.Width);
                if (mover.CurPosition.X > edge.X)
                    mover.Move(Direction.Right, dx);
                else
                    mover.Move(Direction.Left, dx);
            }

            var dy = Math.Abs(mover.CurPosition.Y - edge.Y);
            if (dy <= 3)
            {
                if (mover.CurPosition.Y > edge.Y)
                    mover.Move(Direction.Up, dy);
                else
                    mover.Move(Direction.Down, dy);
            }
            else
            {
                dy = Math.Abs(dy - fieldSize.Height);
                if (mover.CurPosition.X > edge.X)
                    mover.Move(Direction.Down, dy);
                else
                    mover.Move(Direction.Up, dy);
            }
        }

        private void ReachBorderOfWord(Direction directionOfReading)
        {
            if (directionOfReading == Direction.Right)
                while (!fieldManager.IsSubFieldEmpty(0, viewableSize.Height - 1, 0, 2))
                    mover.Move(Direction.Left);
            else
                while (!fieldManager.IsSubFieldEmpty(0, viewableSize.Height - 1, viewableSize.Width - 3, viewableSize.Width - 1))
                    mover.Move(Direction.Right);
            while (!converter.IsLetter(fieldManager.GetFieldAsString()))
                mover.Move(directionOfReading);
        }

        private void ReachLevelOfLetter()
        {
            while (!IsOnSameLevelWithLetter())
                StepToLetter();
        }

        private void StepToLetter()
        {
            var priorityList = new List<int>()
            {
                GetPriorityFor(Direction.Up),
                GetPriorityFor(Direction.Left),
                GetPriorityFor(Direction.Right),
                GetPriorityFor(Direction.Down)
            };
            if (priorityList[0] == priorityList[3])
            {
                priorityList[0] = -1;
                priorityList[3] = -1;
            }
            if (priorityList[1] == priorityList[2])
            {
                priorityList[1] = -1;
                priorityList[2] = -1;
            }
            var mostPriorityDirection = (Direction)priorityList.IndexOf(priorityList.Max());
            mover.Move(mostPriorityDirection);
        }

        private int GetPriorityFor(Direction direction)
        {
            var count = -1;
            switch (direction)
            {
                case (Direction.Down):

                    for (var i = 0; i <= viewableSize.Height / 2; i++)
                    {
                        if (!fieldManager.IsSubFieldEmpty(i, i, 0, viewableSize.Width - 1)) continue;
                        count = viewableSize.Height / 2 - i;
                        break;
                    }
                    break;
                case (Direction.Up):
                    for (var i = viewableSize.Height - 1; i > viewableSize.Height / 2; i--)
                    {
                        if (!fieldManager.IsSubFieldEmpty(i, i, 0, viewableSize.Width - 1)) continue;
                        count = i - viewableSize.Height / 2;
                        break;
                    }
                    break;
                case (Direction.Right):
                    for (var i = 0; i <= viewableSize.Width / 2; i++)
                    {
                        if (!fieldManager.IsSubFieldEmpty(0, viewableSize.Width - 1, i, i)) continue;
                        count = viewableSize.Width / 2 - i;
                        break;
                    }

                    break;
                case (Direction.Left):
                    for (var i = viewableSize.Width - 1; i > viewableSize.Width / 2; i--)
                        if (fieldManager.IsSubFieldEmpty(0, viewableSize.Width - 1, i, i))
                        {
                            count = i - viewableSize.Width / 2;
                            break;
                        }
                    break;
            }

            return count;
        }

        private bool IsOnSameLevelWithLetter()
        {
            var lineCount = 0;
            for (var y = 0; y < viewableSize.Height; y++)
                for (var x = 0; x < viewableSize.Width; x++)
                    if (fieldManager.Field.Value[y, x])
                    {
                        lineCount++;
                        break;
                    }

            return lineCount == viewableSize.Height;
        }
    }
}