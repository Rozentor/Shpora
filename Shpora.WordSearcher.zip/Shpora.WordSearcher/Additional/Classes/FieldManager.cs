﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shpora.WordSearcher
{
    public class FieldManager : IFieldManager
    {
        public Size ViewableSize => new Size(viewableSize.Height, viewableSize.Width);
        public Size FieldSize { get; set; }
        private Size viewableSize;
        public Result<bool[,]> Field { get; set; }
        private readonly GameClient client;

        public FieldManager(GameClient client, Size viewableSize)
        {
            this.client = client;
            this.viewableSize = viewableSize;
            FieldSize = new Size(-1, -1);
        }

        public void SubscribeOn(IMover mover)
        {
            mover.OnStep += OnStep;
        }

        private void OnStep(Direction directionOfMove)
        {
            Field = client.MakeMove(directionOfMove);
        }

        public bool IsSubFieldEmpty(int startY, int endY, int startX, int endX)
        {
            return CountPointsInSubField(startY, endY, startX, endX) == 0;
        }

        public int CountPointsInSubField(int startY, int endY, int startX, int endX)
        {
            if (startY > endY)
            {
                var tmp = startY;
                startY = endY;
                endY = tmp;
            }
            if (startX > endX)
            {
                var tmp = startX;
                startX = endX;
                endX = tmp;
            }
            var counter = 0;
            for (var y = startY; y <= endY; y++)
                for (var x = startX; x <= endX; x++)
                    if (Field.Value[y, x])
                        counter++;
            return counter;
        }

        public string GetFieldAsString()
            => FieldToString(Field.Value, '0', '1');

        private string FieldToString(bool[,] map, char empty, char full)
        {
            var sb = new StringBuilder();
            for (var row = 0; row < map.GetLength(0); row++)
            {
                for (var column = 0; column < map.GetLength(1); column++)
                {
                    sb.Append(map[row, column] ? full : empty);
                }
                sb.Append("\n");
            }
            return sb.ToString();
        }

        public bool IsFieldNotEmpty()
        {
            for (var y = 0; y < ViewableSize.Height; y++)
                for (var x = 0; x < ViewableSize.Width; x++)
                    if (Field.Value[y, x])
                        return true;
            return false;
        }

        public List<Point> GetPoints(Point centerCoordinates)
        {
            return GetPointsInSubField(centerCoordinates, 0, ViewableSize.Height - 1, 0, ViewableSize.Width - 1);
        }

        public List<Point> GetPointsInSubField(Point centerCoordinates, int startY, int endY, int startX, int endX)
        {
            var list = new List<Point>();
            for (var y = startY; y <= endY; y++)
                for (var x = startX; x <= endX; x++)
                    if (Field.Value[y, x])
                    {
                        var Y = centerCoordinates.Y + (y - ViewableSize.Height / 2);
                        var X = centerCoordinates.X + (x - ViewableSize.Width / 2);
                        var point = new Point(Y, X);
                        point.SetCoordinatesInField(FieldSize);
                        list.Add(point);
                    }

            return list;
        }
    }
}