﻿using System.Collections.Generic;
using System.Linq;

namespace Shpora.WordSearcher
{
    class WordCollector : IWordCollector
    {
        public int WordsCount => collectedWords.Count;
        public WordCase FirstWordCase { get; private set; }
        private List<WordCase> wordCases;
        private List<string> collectedWords;

        public WordCollector()
        {
            wordCases = new List<WordCase>();
            collectedWords = new List<string>();
        }

        public void Add(WordCase newWordCase)
        {
            if (FirstWordCase == null)
                FirstWordCase = newWordCase;
            else
                wordCases.Add(newWordCase);
            if (!collectedWords.Contains(newWordCase.Word))
                collectedWords.Add(newWordCase.Word);
        }

        public void FilterWordsByYCoordinate(int y,int dif)
        {
            wordCases = wordCases.Where(wordCase => y - wordCase.LeftTop.Y < dif).ToList();
        }

        public bool Contains(WordCase wordCase)
        {
            return collectedWords.Contains(wordCase.Word);
        }

        public bool ContainsInWordCases(Point point)
        {
            foreach (var wordCase in wordCases)
                if (wordCase.Contains(point))
                    return true;
            if (FirstWordCase != null)
                return FirstWordCase.Contains(point);
            return false;
        }

        public IEnumerable<string> GetAllWords()
        {
            return collectedWords;
        }
    }
}