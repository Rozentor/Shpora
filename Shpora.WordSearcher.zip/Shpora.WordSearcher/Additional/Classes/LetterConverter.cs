﻿using System.Collections.Generic;
using System.IO;

namespace Shpora.WordSearcher
{
    public class ShporaLetterConverter : ILetterConverter
    {
        private readonly Dictionary<string, char> letters;

        public ShporaLetterConverter()
        {
            letters = new Dictionary<string, char>();
            StreamReader sr;
            var dir = new DirectoryInfo(Directory.GetCurrentDirectory() + $"\\shpora_letters");
            foreach (var item in dir.GetFiles())
            {
                sr = new StreamReader(Directory.GetCurrentDirectory() + $"\\shpora_letters\\" + item);
                var str = sr.ReadToEnd();
                str = str.Replace("\n", string.Empty);
                letters.Add(str, item.Name[0]);
            }
        }

        public char ConvertToLetter(string fieldAsString)
        {
            var str = fieldAsString.Replace("\n", string.Empty);
            return letters[str];
        }

        public bool IsLetter(string fieldAsString)
        {
            var str = fieldAsString.Replace("\n", string.Empty);
            return letters.ContainsKey(str);
        }
    }
}