﻿using System;

namespace Shpora.WordSearcher
{
    public class WordCase
    {
        public Point LeftTop { get; set; }
        public Point RightBottom { get; set; }
        public string Word { get; set; }
    }

    public static class WordCaseExtensions
    {
        public static bool Contains(this WordCase wordCase, Point point)
        {
            bool isBetweenForX;
            bool isBetweenForY;

            if (wordCase.RightBottom.X < wordCase.LeftTop.X)
                isBetweenForX = wordCase.LeftTop.X <= point.X || wordCase.RightBottom.X >= point.X;
            else
                isBetweenForX = wordCase.LeftTop.X <= point.X && wordCase.RightBottom.X >= point.X;

            if (wordCase.RightBottom.Y < wordCase.LeftTop.Y)
                isBetweenForY = wordCase.LeftTop.Y <= point.Y || wordCase.RightBottom.Y >= point.Y;
            else
                isBetweenForY = wordCase.LeftTop.Y <= point.Y && wordCase.RightBottom.Y >= point.Y;

            return isBetweenForY && isBetweenForX;
        }

        public static void SetLeftTop(this WordCase wordCase, Point centerOfFirstLetter, Size letterSize, Size fieldSize)
        {
            wordCase.LeftTop = new Point(centerOfFirstLetter.Y - letterSize.Height / 2,
                centerOfFirstLetter.X - letterSize.Width / 2 - 1);
            wordCase.LeftTop.SetCoordinatesInField(fieldSize);
        }

        public static void SetRightBottom(this WordCase wordCase, Point centerOfLastLetter, Size letterSize, Size fieldSize)
        {
            wordCase.RightBottom = new Point(centerOfLastLetter.Y + letterSize.Height / 2,
                centerOfLastLetter.X + letterSize.Width / 2 + 1);
            wordCase.RightBottom.SetCoordinatesInField(fieldSize);
        }
    }
}