﻿using System;

namespace Shpora.WordSearcher
{
    public class Mover : IMover
    {
        public event Action<Direction> OnStep;
        public Point CurPosition { get; }

        public Mover()
        {
            CurPosition = new Point(0, 0);
        }

        public void StepTo(Point point)
        {
            if (point.X > 0)
                Move(Direction.Right);
            else if (point.X < 0)
                Move(Direction.Left);
            if (point.Y > 0)
                Move(Direction.Down);
            else if (point.Y < 0)
                Move(Direction.Up);
        }

        public void Move(Direction directionOfMove)
        {
            Move(directionOfMove, 1);
        }

        public void Move(Direction directionOfMove, int stepAmount)
        {
            for (var i = 0; i < stepAmount; i++)
            {
                switch (directionOfMove)
                {
                    case (Direction.Up):
                        CurPosition.Y--;
                        break;
                    case (Direction.Right):
                        CurPosition.X++;
                        break;
                    case (Direction.Down):
                        CurPosition.Y++;
                        break;
                    case (Direction.Left):
                        CurPosition.X--;
                        break;
                }
                OnStep?.Invoke(directionOfMove);
            }
        }
    }
}