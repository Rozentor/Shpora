﻿using System;

namespace Shpora.WordSearcher
{
    public class Point
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Point(int y, int x)
        {
            X = x;
            Y = y;
        }
    }

    public static class PointExtensions
    {
        public static void SetCoordinatesInField(this Point point, Size bound)
        {
            if (bound.Height > 0)
                if (point.Y < 0)
                    point.Y += bound.Height;
                else
                    point.Y %= bound.Height;
            if (bound.Width > 0)
                if (point.X < 0)
                    point.X += bound.Width;
                else
                    point.X %= bound.Width;
        }
    }
}