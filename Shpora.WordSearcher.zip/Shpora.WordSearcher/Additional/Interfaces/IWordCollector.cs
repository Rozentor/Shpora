﻿using System.CodeDom.Compiler;
using System.Collections.Generic;

namespace Shpora.WordSearcher
{
    public interface IWordCollector
    {
        WordCase FirstWordCase { get; }
        IEnumerable<string> GetAllWords();
        void Add(WordCase wordCase);
        bool Contains(WordCase wordCase);
        bool ContainsInWordCases(Point point);
        int WordsCount { get; }
        void FilterWordsByYCoordinate(int y, int dif);
    }
}