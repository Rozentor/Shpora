﻿namespace Shpora.WordSearcher
{
    public interface IRoadBuilder
    {
        Direction CurDirection { get; }
        Point Destination { get; }
        void SaveDestination();
        bool ReturnedToOldDestination();
    }
}