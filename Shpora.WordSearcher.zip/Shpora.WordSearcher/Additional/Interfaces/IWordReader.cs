﻿namespace Shpora.WordSearcher
{
    public interface IWordReader
    {
        WordCase GetWord(Direction currentMovingDirection, Point edgeOfLetter,Size fieldSize);
        bool IsLetter(string fieldAsString);
    }
}