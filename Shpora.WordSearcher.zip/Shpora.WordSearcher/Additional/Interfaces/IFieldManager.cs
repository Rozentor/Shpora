﻿using System.Collections.Generic;

namespace Shpora.WordSearcher
{
    public interface IFieldManager
    {
        Size ViewableSize { get; }
        Size FieldSize { get; set; }
        Result<bool[,]> Field { get; set; }
        void SubscribeOn(IMover mover);
        bool IsSubFieldEmpty(int startY, int endY, int startX, int endX);
        int CountPointsInSubField(int startY, int endY, int startX, int endX);
        string GetFieldAsString();
        bool IsFieldNotEmpty();
        List<Point> GetPoints(Point centerCoordinates);
        List<Point> GetPointsInSubField(Point centerCoordinates,int startY, int endY, int startX, int endX);
    }
}
