﻿namespace Shpora.WordSearcher
{
    public interface ILetterConverter
    {
        char ConvertToLetter(string field);
        bool IsLetter(string fieldAsString);
    }
}