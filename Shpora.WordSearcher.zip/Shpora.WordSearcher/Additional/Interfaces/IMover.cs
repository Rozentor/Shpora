﻿using System;

namespace Shpora.WordSearcher
{
    public interface IMover
    {
        event Action<Direction> OnStep;
        Point CurPosition { get; }
        void StepTo(Point point);
        void Move(Direction directionOfMove);
        void Move(Direction directionOfMove, int stepAmount);
    }
}