﻿namespace Shpora.WordSearcher
{
    public abstract class RoadBuilder : IRoadBuilder
    {
        public Direction CurDirection { get; protected set; }
        public Point Destination { get; protected set; }
        protected Size size;
        protected Point oldDestination;

        protected RoadBuilder(Size viewableSize, IMover mover, Direction startDirection)
        {
            mover.OnStep += OnStepMade;
            CurDirection = startDirection;
            size = viewableSize;
            oldDestination = new Point(0, 0);
        }

        protected bool ReachedDestination()
        {
            return Destination.X == 0 && Destination.Y == 0;
        }

        protected bool ReachedOldDestination()
        {
            return oldDestination.X == 0 && oldDestination.Y == 0;
        }

        public bool ReturnedToOldDestination()
        {
            if (ReachedDestination() || ReachedOldDestination())
            {
                if (!ReachedOldDestination())
                    Destination = oldDestination;
                oldDestination = new Point(0, 0);
                return true;
            }

            return false;
        }

        public void SaveDestination()
        {
            oldDestination = Destination;
            Destination = new Point(0, 0);
            switch (CurDirection)
            {
                case (Direction.Up):
                    if (oldDestination.Y < 10)
                    {
                        Destination = new Point(-10, 0);
                        oldDestination.Y += 10;
                    }
                    else
                    {
                        Destination = new Point(oldDestination.Y + 1, 0);
                        oldDestination.Y = -1;
                    }
                    break;
                case (Direction.Down):
                    if (oldDestination.Y > 10)
                    {
                        Destination = new Point(10, 0);
                        oldDestination.Y -= 10;
                    }
                    else
                    {
                        Destination = new Point(oldDestination.Y - 1, 0);
                        oldDestination.Y = 1;
                    }
                    break;
            }
        }

        protected abstract Point GetNextPoint();

        protected void OnStepMade(Direction direction)
        {
            switch (direction)
            {
                case (Direction.Up):
                    Destination.Y++;
                    break;
                case (Direction.Right):
                    if (oldDestination.X > 0 && Destination.X == 0)
                        oldDestination.X--;
                    else
                        Destination.X--;
                    break;
                case (Direction.Down):
                    Destination.Y--;
                    break;
                case (Direction.Left):
                    if (oldDestination.X < 0 && Destination.X == 0)
                        oldDestination.X++;
                    else
                        Destination.X++;
                    break;
            }

            if (ReachedDestination() && ReachedOldDestination())
                Destination = GetNextPoint();
        }
    }
}