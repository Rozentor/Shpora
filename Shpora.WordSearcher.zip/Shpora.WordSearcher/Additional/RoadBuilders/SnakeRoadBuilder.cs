﻿namespace Shpora.WordSearcher
{
    public class SnakeRoadBuilder : RoadBuilder
    {
        private int passedPointsCount = -1;
        private Size fieldSize;
        public SnakeRoadBuilder(Size viewableSize, IMover mover, Size fieldSize) : base(viewableSize, mover, Direction.Right)
        {
            this.fieldSize = fieldSize;
            Destination = GetNextPoint();
        }

        protected override Point GetNextPoint()
        {
            passedPointsCount++;
            ChangeDirection();
            switch (CurDirection)
            {
                case (Direction.Right):
                    return new Point(0, fieldSize.Width - 14);
                case (Direction.Down):
                    return new Point(7, 0);
                case (Direction.Left):
                    return new Point(0, -(fieldSize.Width - 14));
                default:
                    return null;
            }
        }

        private void ChangeDirection()
        {
            switch (passedPointsCount % 4)
            {
                case (0):
                    CurDirection = Direction.Right;
                    break;
                case (1):
                    CurDirection = Direction.Down;
                    break;
                case (2):
                    CurDirection = Direction.Left;
                    break;
                case (3):
                    CurDirection = Direction.Down;
                    break;
            }
        }
    }
}