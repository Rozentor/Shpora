﻿namespace Shpora.WordSearcher
{
    public class LinearRoadBuilder : RoadBuilder
    {
        public LinearRoadBuilder(Size viewableSize, IMover mover) : base(viewableSize, mover, Direction.Right)
        {
            Destination = GetNextPoint();
        }

        protected override Point GetNextPoint()
        {
            return new Point(0, 1);
        }
    }
}