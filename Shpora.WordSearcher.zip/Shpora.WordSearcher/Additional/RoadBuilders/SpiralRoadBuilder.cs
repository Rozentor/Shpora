﻿namespace Shpora.WordSearcher
{
    public class SpiralRoadBuilder : RoadBuilder
    {
        private int passedPointsCount;

        public SpiralRoadBuilder(Size viewableSize, IMover mover) : base(viewableSize, mover, Direction.Up)
        {
            Destination = GetNextPoint();
        }

        protected override Point GetNextPoint()
        {
            passedPointsCount++;
            ChangeDirection();
            switch (CurDirection)
            {
                case (Direction.Up):
                    return new Point(-(size.Height * 2 - 2) * (passedPointsCount / 2 + 1), 0);
                case (Direction.Right):
                    return new Point(0, (size.Width * 2 - 2) * (passedPointsCount / 2 + 1));
                case (Direction.Down):
                    return new Point((size.Height * 2 - 2) * (passedPointsCount / 2 + 1), 0);
                case (Direction.Left):
                    return new Point(0, -(size.Width * 2 - 2) * (passedPointsCount / 2 + 1));
                default:
                    return null;
            }
        }

        private void ChangeDirection()
        {
            switch (CurDirection)
            {
                case (Direction.Up):
                    CurDirection = Direction.Right;
                    break;
                case (Direction.Right):
                    CurDirection = Direction.Down;
                    break;
                case (Direction.Down):
                    CurDirection = Direction.Left;
                    break;
                case (Direction.Left):
                    CurDirection = Direction.Up;
                    break;
            }
        }

    }
}